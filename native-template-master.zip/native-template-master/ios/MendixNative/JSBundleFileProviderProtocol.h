//
//  Copyright (c) Mendix, Inc. All rights reserved.
//

@protocol JSBundleFileProviderProtocol <NSObject>

+ (nullable NSURL *)getBundleUrl;

@end
