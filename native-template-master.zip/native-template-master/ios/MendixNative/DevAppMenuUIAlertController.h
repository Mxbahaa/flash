//
//  Copyright (c) Mendix, Inc. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface DevAppMenuUIAlertController : UIAlertController
@end
